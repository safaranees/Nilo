-- phpMyAdmin SQL Dump
-- version 2.11.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 08, 2013 at 09:44 AM
-- Server version: 5.0.45
-- PHP Version: 5.2.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `creditcard`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(6) unsigned NOT NULL auto_increment,
  `title` varchar(100) NOT NULL default '',
  `author` varchar(100) NOT NULL default '',
  `price` double NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `title`, `author`, `price`) VALUES
(1, 'Where God Went Wrong', 'Oolon Colluphid', 50),
(4, 'Bible', 'god', 250),
(5, 'C++', 'aaaaa', 366),
(7, 'Narayana Guru', 'Business Maths', 250),
(8, 'Expert', 'Sathish', 550),
(10, 'Franklin', 'PHP', 264);

-- --------------------------------------------------------

--
-- Table structure for table `carddetail`
--

CREATE TABLE `carddetail` (
  `holder` char(20) NOT NULL,
  `bnknam` char(20) NOT NULL,
  `brnhnam` char(20) NOT NULL,
  `typ` char(20) NOT NULL,
  `cno` varchar(20) NOT NULL,
  `amtlimt` varchar(25) NOT NULL,
  `q1` char(30) NOT NULL,
  `answer` varchar(20) NOT NULL,
  `cardpin` varchar(10) NOT NULL,
  PRIMARY KEY  (`cno`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `carddetail`
--

INSERT INTO `carddetail` (`holder`, `bnknam`, `brnhnam`, `typ`, `cno`, `amtlimt`, `q1`, `answer`, `cardpin`) VALUES
('we', 'IOB', 'R.s Puram', 'MasterCard', '340000000000009', '100000 to 150000', 'Personal Mobile Number', '1234', '4YX3AS5'),
('ABCD', 'Bank Of India', 'R.s Puram', 'MasterCard', '5500000000000004', '49999', 'My Byk Num', '1234', 'GMJKSU9'),
('rrrrrrr', 'dddd', 'ddddd', 'MasterCard', '5555555555554444', '100000 to 150000', 'Personal Mobile Number', 'dddddd', '4VQ9MAD'),
('Siva', 'IOB', 'R.s Puram', 'MasterCard', '6011000000000004', '49999', 'Personal Mobile Number', '987', '39SJXN2');

-- --------------------------------------------------------

--
-- Table structure for table `pur`
--

CREATE TABLE `pur` (
  `id` int(10) NOT NULL auto_increment,
  `hnam` char(30) NOT NULL,
  `pay` char(30) NOT NULL,
  `total` int(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `pur`
--


-- --------------------------------------------------------

--
-- Table structure for table `registor`
--

CREATE TABLE `registor` (
  `id` int(10) NOT NULL auto_increment,
  `name` char(20) NOT NULL,
  `dob` varchar(100) NOT NULL,
  `gen` char(10) NOT NULL,
  `address` varchar(30) NOT NULL,
  `mail` varchar(20) NOT NULL,
  `mobno` varchar(10) NOT NULL,
  `usname` varchar(20) NOT NULL,
  `pass` varchar(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `registor`
--

INSERT INTO `registor` (`id`, `name`, `dob`, `gen`, `address`, `mail`, `mobno`, `usname`, `pass`) VALUES
(1, 'Richard', '01/01/2013', 'Male', 'OOTY', 'rich@gmail.com', '9876543210', 'rich', 'rich'),
(2, 'Mahendran .R', '17/06/XXXX', 'Male', 'CBE', 'mahe@gmail.com', '9988776655', 'mahe', 'mahe'),
(3, 'Rajkumar .R', '28/02/XXXX', 'Male', 'CBE', 'raj@gmail.com', '9998887770', 'raj', 'raj');
