-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 01, 2011 at 12:27 PM
-- Server version: 5.1.37
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `creditcard`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE IF NOT EXISTS `books` (
  `id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT '',
  `author` varchar(100) NOT NULL DEFAULT '',
  `price` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `title`, `author`, `price`) VALUES
(1, 'Where God Went Wrong', 'Oolon Colluphid', 50),
(4, 'Bible', 'god', 250),
(5, 'C++', 'aaaaa', 366),
(7, 'Narayana Guru', 'Business Maths', 250),
(8, 'Expert', 'Sathish', 550),
(10, 'Franklin', 'PHP', 264);

-- --------------------------------------------------------

--
-- Table structure for table `carddetail`
--

CREATE TABLE IF NOT EXISTS `carddetail` (
  `holder` char(20) NOT NULL,
  `bnknam` char(20) NOT NULL,
  `brnhnam` char(20) NOT NULL,
  `typ` char(20) NOT NULL,
  `cno` varchar(20) NOT NULL,
  `amtlimt` varchar(25) NOT NULL,
  `q1` char(30) NOT NULL,
  `answer` varchar(20) NOT NULL,
  `cardpin` varchar(10) NOT NULL,
  PRIMARY KEY (`cno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `carddetail`
--

INSERT INTO `carddetail` (`holder`, `bnknam`, `brnhnam`, `typ`, `cno`, `amtlimt`, `q1`, `answer`, `cardpin`) VALUES
('we', 'IOB', 'R.s Puram', 'MasterCard', '340000000000009', '100000 to 150000', 'Personal Mobile Number', '1234', '4YX3AS5'),
('ABCD', 'Bank Of India', 'R.s Puram', 'MasterCard', '5500000000000004', '49999', 'My Byk Num', '1234', 'GMJKSU9'),
('rrrrrrr', 'dddd', 'ddddd', 'MasterCard', '5555555555554444', '100000 to 150000', 'Personal Mobile Number', 'dddddd', '4VQ9MAD'),
('Siva', 'IOB', 'R.s Puram', 'MasterCard', '6011000000000004', '49999', 'Personal Mobile Number', '987', '39SJXN2');

-- --------------------------------------------------------

--
-- Table structure for table `pur`
--

CREATE TABLE IF NOT EXISTS `pur` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `hnam` char(30) NOT NULL,
  `pay` char(30) NOT NULL,
  `total` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `pur`
--


-- --------------------------------------------------------

--
-- Table structure for table `registor`
--

CREATE TABLE IF NOT EXISTS `registor` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` char(20) NOT NULL,
  `dob` date NOT NULL,
  `gen` char(10) NOT NULL,
  `address` varchar(30) NOT NULL,
  `mail` varchar(20) NOT NULL,
  `mobno` int(10) NOT NULL,
  `usname` varchar(20) NOT NULL,
  `pass` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `registor`
--

INSERT INTO `registor` (`id`, `name`, `dob`, `gen`, `address`, `mail`, `mobno`, `usname`, `pass`) VALUES
(1, 'Franklin', '2030-08-10', 'Male', 'Race course', 'franklincbe@gmail.co', 2147483647, 'frank', 'aaaa'),
(2, 'sathish', '2022-12-10', 'Male', 'Pelamadu', 'sat@gmail.com', 2147483647, 'sat', 'sat'),
(3, 'Frank', '2022-12-10', 'Male', 'aaaa', 'aaaa@gmail.com', 2147483647, 'aaaa', 'aaaa'),
(4, 'Frank', '2001-12-10', 'Male', 'Chennai', 'bbbb@gmail.com', 2147483647, 'vvvv', 'vvvv'),
(5, 'Frank', '2001-12-10', 'Male', 'Chennai', 'bbbb@gmail.com', 2147483647, 'vvvv', 'vvvv'),
(6, 'ABCD', '2022-12-10', 'Male', 'retert', 'cccc@gmail.com', 2147483647, 'aaaa', 'bbbb'),
(7, 'Aaaa', '0000-00-00', 'Male', 'KOVAI', 'AAA@gmail.com', 2147483647, 'oooo', 'oooo');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
