<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>CREDIT CARD</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="styles.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
#Layer1 {
	position:absolute;
	width:301px;
	height:207px;
	z-index:1;
	left: 14px;
	top: 745px;
}
-->
</style>
</head>
<body>

<div id="bg">

<div id="main">
<div id="main_bot">
<!-- header begins -->
<div id="header">
	<div id="logo">
        <h1><strong>DISTRIBUTED DATA MINING IN CREDIT<br /> CARD FRAUD DETECTION </strong></h1>
        <h2><a href="http://www.metamorphozis.com/" id="metamorph"></a></h2>
</div>
    <div id="buttons">
        <table width="617" height="88">
          <tr>
          <td width="113" height="84" class="first"><a href="Adminhome.html"  title="">Home</a></td>
		  <td width="135"><a href="add.php" class="last_b" title="">Add Products</a></td>
          <td width="115"><a href="clientde.php" title="">Client Details  </a></td>
		  <td width="119"><a href="cardde.php" title="">Card Holder Details  </a></td>
          <td width="249" ><a href="#" title="" class="last_b">Purchase Details </a></td>
        </tr>
		</table>
    </div>
</div>
<!-- header ends -->
    <!-- content begins -->
    	<div id="content">
        	<div id="left">
            	<h1><span class="left_b"><strong><em>DETECTION SYSTEM</em></strong>.</span></h1>
           	  <div class="left_b">
              	  <p>THIS  SCALABLE BLACK-BOX APPROACH FOR BUILDING<br />
EFFICIENT FRAUD DETECTORS  CAN SIGNIFICANTLY REDUCE<br />
LOSS DUE TO ILLEGITIMATE  BEHAVIOR. IN MANY CASES, THE<br />
AUTHORS’ METHODS  OUTPERFORM A WELL-KNOWN, STATEOF-<br />
THE-ART COMMERCIAL FRAUD-DETECTION SYSTEM </p>
       	      </div>
              	<div class="left_b"><em><h3>Credit card fraud </h3></em>&nbsp;
                Unfortunately credit card fraud is a fact-of-life for all merchants who   accept credit card payments as part of their business operation. With   the increasing transition to online merchandising via the Internet,   online credit card fraud is a serious issue. A business requires a sound   order-confirmation-system if you want to avoid getting 'ripped-off',   being subject to bank 'charge-backs' and/or constantly arranging refunds   for fraudulent transactions..</div>
              	<div class="read_l"><a href="#"></a></div>
          </div>  
            <div id="right">
            	<div class="right_top"></div>
              	<div class="right_s">
                    <h2> Purchase Details &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;<a href="../index.html">LOgOut..</a></h2>
                    <div class="text"><br />
					<table width="639" height="112" border="3"  color="#330000">
					<tr>
					<td width="77" height="47"><B>NAME</B></td>
					<td width="75"><B>PAYMENT CARD</B></td>
					<td width="78"><B>AMOUNT</B></td>
					
				
					</tr>
					<?PHP
						include("../connection.php");
						
						$sele="select * from PUR";
						$result=mysql_query($sele);
						while($row=mysql_fetch_array($result))
						{
						?>
						<tr><td height="53"><?php echo $row['hnam']; ?></td>
						<td><?php echo $row['pay']; ?></td>
						<td><?php echo $row['total']; ?></td>
						
						
						</tr>
						<?php
						}
						?>
					</table>
                    	<p>&nbsp;</p>
                    	<br />
                        <div class="read_l"><a href="#"></a></div>
                  </div>
                  <h2>Our approach</h2>
                	<div class="col_l">
                      <img src="images/img2.jpg" width="124" height="93" class="img" alt="" />
                      <p><strong>In today’s</strong> increasingly  electronic society and with the rapid advances of electronic commerce on the  Internet, the use of credit cards for purchases has become convenient and  necessary. Credit card transactions have become the de facto standard for  Internet and Webbased e-commerce. The US government estimates that credit cards  accounted for approximately US $13 billion in Internet sales during 1998. This  figure is expected to grow rapidly each year. However, the growing number of credit  card transactions provides more opportunity for thieves to steal credit card  numbers and subsequently commit fraud. When banks lose  money because of credit card fraud, cardholders pay for all of that loss  through higher interest rates, higher fees, and reduced benefits.Hence, it is in  both the banks’</p>
                    	<br />
                      <div class="read_l"><a href="#">read more</a></div><br />
                  </div>
                  	<div class="col_r">
                      	<img src="images/img3.jpg" width="124" height="93" class="img" alt="" />
                      	<p><strong>Cardholders</strong>’interest to  reduce illegitimate use of credit cards by early fraud detection. For many  years, the credit card industry has studied computing models for automated  detection systems; recently, these models have been the subject of academic research,  especially with respect to e-commerce. The credit card fraud-detection domain presents  a number of challenging issues for data mining:<br />
                      	  • There are millions of credit card  transactions processed each day. Mining such massive amounts of data requires  highly<br />
                      	  efficient techniques  that scale.<br />
                      	  • The data are highly  skewed—many more transactions are legitimate than fraudulent.<br />
                   	  Typical accuracy-based  mining techniques can generate highly accurate fraud detectors by simply predicting </p>
                      	<br />
                      <div class="read_l"><a href="#">read more</a></div><br />
               	  </div>
                    <div style="clear: both"><img src="images/spaser.gif" alt="" width="1" height="1" /></div>
              </div>
              	<div class="right_bot"></div>
            </div> 
            <div style="clear: both"><img src="images/spaser.gif" alt="" width="1" height="1" /></div>
	  </div>
    <!-- content ends -->
    <!-- footer begins -->
    <div id="footer">
  Copyright  2010. Designed by Franklin<a href="http://www.metamorphozis.com/" title="Free Web Templates"></a><br />
		<a href="#">Privacy Policy</a> | <a href="#">Terms of Use</a> | <a href="http://validator.w3.org/check/referer" title="This page validates as XHTML 1.0 Transitional"><abbr title="eXtensible HyperText Markup Language">XHTML</abbr></a> | <a href="http://jigsaw.w3.org/css-validator/check/referer" title="This page validates as CSS"><abbr title="Cascading Style Sheets">CSS</abbr></a></div>
<!-- footer ends -->
</div>
</div>
</div>
</body>
</html>
