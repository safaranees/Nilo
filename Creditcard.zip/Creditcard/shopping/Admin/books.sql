-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 01, 2010 at 10:54 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `stock`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(6) unsigned NOT NULL auto_increment,
  `title` varchar(100) NOT NULL default '',
  `author` varchar(100) NOT NULL default '',
  `price` double NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `title`, `author`, `price`) VALUES
(1, 'Where God Went Wrong', 'Oolon Colluphid', 50),
(2, 'Some More of God''s Greatest Mistakes', 'Oolon Colluphid', 75),
(3, 'Who Is This God Person Anyway?', 'Oolon Colluphid', 82.6),
(4, 'Bible', 'god', 250),
(5, 'C++', 'aaaaa', 366),
(6, 'AAAAAA', 'cccc', 580),
(7, 'Narayana Guru', 'Business Maths', 250),
(8, 'Expert', 'Sathish', 550),
(9, 'qqqq', 'qqq', 250);
