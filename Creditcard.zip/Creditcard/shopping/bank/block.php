<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script type="text/javascript"  language="javascript">
 function ProcA () 
	 {
		alert ("The Card Has being Blocked");
	 }
	  function ProcB () 
	 {
		alert ("Type Correct Pin Number");
	 }
	 function ProcC () 
	 {
		alert ("Pin Number is Empty");
	 }
	 </script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<?php
include "connection.php";
$mode=$_GET['mode'];
$cpin=$_POST['pin'];

//echo $cpin;
//if($mode=='block')
//{
if($cpin=="")
{
echo "<script language=javascript>ProcC()</script>";
echo "<meta http-equiv='refresh' content='0;url=cardblock.php'>";
}
else if($mode=='del')
{
$dlete="delete from carddetail where cardpin='$cpin'";
mysql_query($dlete);

echo "<script language=javascript>ProcA()</script>";
echo "<meta http-equiv='refresh' content='0;url=index.html'>";
}
else
{
echo "<script language=javascript>ProcB()</script>";
echo "<meta http-equiv='refresh' content='0;url=cardblock.php'>";
}

//}
?>
</body>
</html>
