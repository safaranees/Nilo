<?php session_start();
include "connection.php";

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Bank</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>
<script type="text/javascript"  language="javascript">


	  function ProcB () 
	 {
		alert ("Enter All The Values");
	 }
	  function ProcA () 
	 {
		alert ("Registered Successfully <?PHP echo $Cname; ?>");
	 }
	  function ProcC () 
	 {
		alert ("Password Not Matched ");
	 }
	  function alertbox (obj) 
	 {
		alert (obj);
	 }
	 function isEmpty(inputStr) {
if ( inputStr == "" ) {
return true;
}
else {
return false;
}
}
function passLength()
{
if(document.getElementById("p").value<16)
{
alert("Enter the Correct Card No");
}
}
	 </script>

<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>CLIENT</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="styles.css" rel="stylesheet" type="text/css" />
<script type="text/javascript"  language="javascript">
	 history.forward();
	 </script>
<script type="text/javascript">

function Mod10(ccNumb) {  // v2.0
var valid = "0123456789"  // Valid digits in a credit card number
var len = ccNumb.length;  // The length of the submitted cc number
var iCCN = parseInt(ccNumb);  // integer of ccNumb
var sCCN = ccNumb.toString();  // string of ccNumb
sCCN = sCCN.replace (/^\s+|\s+$/g,'');  // strip spaces
var iTotal = 0;  // integer total set at zero
var bNum = true;  // by default assume it is a number
var bResult = false;  // by default assume it is NOT a valid cc
var temp;  // temp variable for parsing string
var calc;  // used for calculation of each digit

// Determine if the ccNumb is in fact all numbers
for (var j=0; j<len; j++) {
  temp = "" + sCCN.substring(j, j+1);
  if (valid.indexOf(temp) == "-1"){bNum = false;}
}

// if it is NOT a number, you can either alert to the fact, or just pass a failure
if(!bNum){
  /*alert("Not a Number");*/bResult = false;
}

// Determine if it is the proper length 
if((len == 0)&&(bResult)){  // nothing, field is blank AND passed above # check
  bResult = false;
} else{  // ccNumb is a number and the proper length - let's see if it is a valid card number
  if(len >= 15){  // 15 or 16 for Amex or V/MC
    for(var i=len;i>0;i--){  // LOOP throught the digits of the card
      calc = parseInt(iCCN) % 10;  // right most digit
      calc = parseInt(calc);  // assure it is an integer
      iTotal += calc;  // running total of the card number as we loop - Do Nothing to first digit
      i--;  // decrement the count - move to the next digit in the card
      iCCN = iCCN / 10;                               // subtracts right most digit from ccNumb
      calc = parseInt(iCCN) % 10 ;    // NEXT right most digit
      calc = calc *2;                                 // multiply the digit by two
      // Instead of some screwy method of converting 16 to a string and then parsing 1 and 6 and then adding them to make 7,
      // I use a simple switch statement to change the value of calc2 to 7 if 16 is the multiple.
      switch(calc){
        case 10: calc = 1; break;       //5*2=10 & 1+0 = 1
        case 12: calc = 3; break;       //6*2=12 & 1+2 = 3
        case 14: calc = 5; break;       //7*2=14 & 1+4 = 5
        case 16: calc = 7; break;       //8*2=16 & 1+6 = 7
        case 18: calc = 9; break;       //9*2=18 & 1+8 = 9
        default: calc = calc;           //4*2= 8 &   8 = 8  -same for all lower numbers
      }                                               
    iCCN = iCCN / 10;  // subtracts right most digit from ccNum
    iTotal += calc;  // running total of the card number as we loop
  }  // END OF LOOP
  if ((iTotal%10)==0){  // check to see if the sum Mod 10 is zero
    bResult = true;  // This IS (or could be) a valid credit card number.
  } else {
    bResult = false;  // This could NOT be a valid credit card number
    }
  }
}
// change alert to on-page display or other indication as needed.
if(bResult) {
  alert("This IS a valid Credit Card Number!");
}
if(!bResult){
  alert("This is NOT a valid Credit Card Number!");
  document.getElementById("CNUM").value="";
}
  return bResult; // Return the results
}
</script>
</head>
<body>
<?php
if(isset($_POST['save']) && $_POST['save']!="")


//---------------------------- First IF Starting--------------------------------
{
$holder=$_POST['holnam'];
$bnknam=$_POST['bnknam'];
$brnhnam=$_POST['bnhnam'];
$typ=$_POST['typ'];
$cno=$_POST['CreditCard'];
$amtlimt=$_POST['amtlimt'];
$q1=$_POST['q1'];
$ans=$_POST['ans'];
$secturity=$_POST['security_code'];


if($holder=="" ||$bnknam=="" ||$brnhnam=="" ||$typ==""||$cno==""||$amtlimt==""||$q1==""||$ans==""||$secturity=="")
{

echo "<script language=javascript>ProcB()</script>";

}
else
{

$characters = array(
"A","B","C","D","E","F","G","H","J","K","L","M",
"N","P","Q","R","S","T","U","V","W","X","Y","Z",
"1","2","3","4","5","6","7","8","9");

//make an "empty container" or array for our keys
$keys = array();

//first count of $keys is empty so "1", remaining count is 1-6 = total 7 times
while(count($keys) < 7) {
    //"0" because we use this to FIND ARRAY KEYS which has a 0 value
    //"-1" because were only concerned of number of keys which is 32 not 33
    //count($characters) = 33
    $x = mt_rand(0, count($characters)-1);
    if(!in_array($x, $keys)) {
       $keys[] = $x;
    }
}

foreach($keys as $key){
   $random_chars .= $characters[$key];
}
session_start();
//echo $random_chars;
echo $ans;
echo $bnknam;

$ins = "insert into carddetail(holder,bnknam,brnhnam,typ,cno,amtlimt,q1,answer,cardpin)values('$holder','$bnknam','$brnhnam','$typ','$cno','$amtlimt','$q1','$ans','$random_chars')";
$_SESSION['random_chars']=$random_chars;
		if (!mysql_query($ins))
      {
      die ('Error: ' . mysql_error());
      }
	  	   echo "<script language=javascript>ProcA()</script>";
	   

	   echo "<meta http-equiv='refresh' content='0;url=cardno.php'>";

}

//---------------------------First ELSE Ending----------------------------------



}


?>

   <!-- Begin Wrapper -->
   <div id="wrapper">
   
         <!-- Begin Header -->
         <div id="header">
		 
                <div class="logo">
		<h1 id="lineone"><strong><font color="#000000" face="Algerian" size="+2">DISTRIBUTED DATA MINING IN CREDIT<br />
CARD FRAUD DETECTION</font></strong></h1> 
		<h2 id="linetwo"></h2>
           </div>
	 
			   
		 </div>
		 <!-- End Header -->
		 
		 <!-- Begin Navigation -->
         <div id="navigation">
		 
	<div class="menu">

	        <ul>
			<li><a href="index.html"> Home </a>
			</li>
			<li><a href="#" title="#">Card Registration </a></li>
			<li><a href="abtous.html">About Us</a></li>
                        <li><a href="cardblock.php">Block Card</a></li>
                        <li><a href="contact.html">Contact Us</a></li>
						 <li><a href="../index.html">LoG OuT</a></li>
		</ul>
	</div>
	 
			   
		 </div>
		 <!-- End Navigation -->
		 
		 <!-- Begin Left Column -->
		 <div id="leftcolumn">
		 
			<div id="leftbox">
                        
                        <div class="col-l">
	        <ul>
			<li><a href="" title="free business templates">Home</a></li>
			<li><a href="#" title="#">Card Registration</a><a href="" title="earn money online"></a></li>
			<li><a href="#" title="#">About Us</a></li>
                        <li><a href="#" title="#">Block Card</a></li>
                        <li><a href="#" title="#">Contact Us</a></li>
		</ul>
              </div>
           </div>
                        <div id="leftboxbottom"></div>
            
                             <br/>

			<div id="leftbox-2">
                        
                        <div class="col-l">
	                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec rutrum neque eu nisl. Morbi eget felis. Vestibulum feugiat lectus ut magna. Ut interdum ipsum nec metus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Ut eget augue .</p>
                        </div>
                        </div>
                        <div id="leftboxbottom-2"></div>
		 
		 </div>
		 <!-- End Left Column -->
		 
		 <!-- Begin Right Column -->
	 <div id="rightcolumn">
                 <blockquote><p><span class="title"><font face="Algerian" size="+2">REGISTRATION FORM for CARD HOLDER</font></span></p>
                 </blockquote>
		       
             <h4>&nbsp;</h4>	 
				 <form action="" method="post" name="Form1">
			  <table width="550" height="419" border="3" bordercolor="#000000" background="images/background5.jpg">
                      <tr>
					<td width="191" height="31" align=""><font color="#000000"><B>Card Holder Name </B></font></td>
					<td width="330" align="center"><input type="text" name="holnam" /></td></tr>
					<td height="31" align=""><font color="#000000"><B>Bank Name</B></font> </td>
					<td align="center"><input type="text" name="bnknam" /></td></tr>
					<td height="30" align=""><font color="#000000"><B>Branch Name </B></font></td>
					<td align="center"><input type="text" name="bnhnam" /></td></tr>
					<td height="32" align=""><font color="#000000"><B>Card Type</B></font> </td>
					<td align="center">
					<select name="typ">
					<option>Select the Card type</option>
					 <option value="MasterCard">MasterCard</option>
      <option value="American Express">American Express</option>
      <option value="Carte Blanche">Carte Blanche</option>
      <option value="Diners Club">Diners Club</option>

      <option value="Discover">Discover</option>
      <option value="Enroute">enRoute</option>
      <option value="JCB">JCB</option>
      <option value="Maestro">Maestro</option>
      <option value="MasterCard">MasterCard</option>
      <option value="Solo">Solo</option>

      <option value="Switch">Switch</option>
      <option value="Visa">Visa</option>
      <option value="Visa Electron">Visa Electron</option>
      <option value="LaserCard">Laser</option>

					</select></td></tr>
					<tr><td height="33" align=""><font color="#000000"><B>Card No </B></font></td>
					<td align="center"><input type="text" name="CreditCard" ID="CNUM" size="18" maxlength="16" style="border: 1px solid #000098; padding: 3px;"/></td></tr>
					<tr><td height="74" align=""><font color="#000000"><B>Amount Limit </B></font></td>
					<td align="">
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="amtlimt" value="100000 to 150000" />&nbsp;<B>1 lakh to 1.5 lakh</B> <br />
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="amtlimt" value="50000 to 99999 " />&nbsp;<B>Above 50000 to Below 100000</B> <br />
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="amtlimt" value="49999" />&nbsp;<B>Below 50000 </B></td></tr>
						<tr><td height="32" align=""><font color="#000000"><B>Question 1 </B></font></td>
					<td align="center"><select name="q1">
					<option>Select the Question</option>
					 <option value="Personal Mobile Number">Personal Mobile Number</option>
      <option value="Name of My Pet">Name of My Pet</option>
      <option value="My Byk Num">My Byk Num</option>
      <option value="My Co_Brother Name">My Co_Brother Name</option>

      <option value="My Enemy Name">My Enemy Name</option>
      <option value="My Dish">My Dish</option>
      <option value="My Girl Name">My Girl Name</option>
      <option value="My Boy Name">My Boy Name</option>
      <option value="My Nick NAme">My Nick NAme</option>
      <option value="My Name">My Name</option>

     
					</select></td></tr>
					<tr><td height="33" align="" ><font color="#000000"><B>Answer 1 </B></font></td>
					<td align="center"><input type="text" name="ans" /></td></tr>
					<tr><td height="40" colspan="2" align="center"><img src="CaptchaSecurityImages.php?width=100&height=40&characters=5" /></td>
					<tr><td height="27" align=""><font color="#000000"><B>Security Code:</B></font></td>
					<td align="center"><input id="security_code" name="security_code" type="text" /></td></tr>
					<TR><TD height="26" colspan="2" align="CENTER"><input type="submit" value="SUBMIT" name="save" /></TD></TR>
			  </table>
			  </form>
            <p>&nbsp;</p>

                 <div class="clear"></div>

	             <div class="clear"></div>
		</div>

		 <!-- End Right Column -->
		 
		 <!-- Begin Footer -->
 <div id="footer">
	<p id="links">Valid XHTML | Valid CSS</p>
	<p id="legal">Copyright &copy; 2007  by Free CSS Templates  Designed by FEEE CSS TEMPLATES.</p>
</div> <!-- End Footer -->
		 
   </div>
   <!-- End Wrapper -->
   
</body>
</html>
