<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Bank</title>
<link rel="stylesheet" type="text/css" href="style.css" />


</head>
<body>
<!-- Begin Wrapper -->
<div id="wrapper">
  <!-- Begin Header -->
  <div id="header">
    <div class="logo">
      <h1 id="lineone"><strong><font color="#000000" face="Algerian" size="+2">DISTRIBUTED DATA MINING IN CREDIT<br />
        CARD FRAUD DETECTION</font></strong></h1>
      <h2 id="linetwo"></h2>
    </div>
  </div>
  <!-- End Header -->
  <!-- Begin Navigation -->
  <div id="navigation">
    <div class="menu">
      <ul>
        <li><a href="index.html"> Home </a> </li>
        <li><a href="reg.php">Card Registration </a></li>
        <li><a href="abtous.html">About Us</a></li>
        <li><a href="">Block Card</a></li>
        <li><a href="contact.html">Contact Us</a></li>
        <li><a href="../index.html">LoG OuT</a></li>
      </ul>
    </div>
  </div>
  <!-- End Navigation -->
  <!-- Begin Left Column -->
  <div id="leftcolumn">
    <div id="leftbox">
      <div class="col-l">
        <ul>
          <li><a href="" title="free business templates">Home</a></li>
          <li><a href="#" title="#">Card Registration</a><a href="" title="earn money online"></a></li>
          <li><a href="#" title="#">About Us</a></li>
          <li><a href="#" title="#">Block Card</a></li>
          <li><a href="#" title="#">Contact Us</a></li>
        </ul>
      </div>
    </div>
    <div id="leftboxbottom"></div>
    <br/>
    <div id="leftbox-2">
      <div class="col-l">
        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec rutrum neque eu nisl. Morbi eget felis. Vestibulum feugiat lectus ut magna. Ut interdum ipsum nec metus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Ut eget augue .</p>
      </div>
    </div>
    <div id="leftboxbottom-2"></div>
  </div>
  <!-- End Left Column -->
  <!-- Begin Right Column -->
  <div id="rightcolumn">
    <blockquote>
      <p><span class="title"><b>Card Block </b></span></p>
      <form action="cardblock.php" method="post" enctype="multipart/form-data" onsubmit="return valid()" name="form1">
        <table width="393" height="252">
          <tr>
            <td width="217" height="38" align="center"><B>Holder Name </B></td>
            <td width="362" align="center"><input type="text" name="hnam" /></td>
          </tr>
          <td height="51" align="center"><B>Bank</B> </td>
            <td align="center"><input type="text" name="bnam" /></td>
          </tr>
          <td height="54" align="center"><B>Card No </B></td>
            <td align="center"><input type="text" name="cno" /></td>
          </tr>
          <td align="center"><B>Pin No </B> </td>
            <td align="center"><input type="password" name="pin" /></td>
          </tr>
          <TR>
            <TD height="45" colspan="2" align="CENTER"><input type="submit" value="SEND" name="submit" /></TD>
          </TR>
        </table>
      </form>

    </blockquote>
    <div class="clear"></div>
    <div id="triplebox">
      <div class="col"> <img src="images/globe-s.gif" class="floatTL" alt="business" />
        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>
      </div>
      <div class="col"> <img src="images/globe-s.gif" class="floatTL" alt="business" />
        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>
      </div>
      <div class="col"> <img src="images/globe-s.gif" class="floatTL" alt="business" />
        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. </p>
      </div>
    </div>
    <div class="clear"></div>
    <div id="tripleboxbottom"></div>
  </div>
  <!-- End Right Column -->
  <!-- Begin Footer -->
 <div id="footer">
	<p id="links">Valid XHTML | Valid CSS</p>
	<p id="legal">Copyright &copy; 2007  by Free CSS Templates  Designed by FEEE CSS TEMPLATES.</p>
</div>
  <!-- End Footer -->
</div>
<!-- End Wrapper -->
</body>
</html>
<script type="text/javascript">
var frm = document.form1;

function valid(){

if(frm.hnam.value =="") { alert("Please Enter The Card Holder Name"); frm.hnam.focus(); return false }

if(frm.bnam.value =="") { alert("Please Enter The Bank Name"); frm.bnam.focus(); return false }

if(frm.cno.value =="") { alert("Please Enter The Card No"); frm.cno.focus(); return false }

if(frm.pin.value =="") { alert("Please Enter The Pin No"); frm.pin.focus(); return false }

}
</script>
	  <?php
	 if(isset($_POST["submit"]))
	  {
	  include("connection.php");
	   $pi=$_POST["pin"];//echo $pi;
	   $bn=$_POST["bnam"];//echo $bn;
	   $cno=$_POST["cno"];//echo $cno;
	   $ho=$_POST["hnam"];//echo $ho;
	   $q="delete from carddetail where cardpin='$pi'AND bnknam='$bn' AND cno='$cno' AND holder='$ho'";
	   $res=mysql_query($q);
	   if(!$res)
	   {
	   echo "<script language=javascript>alert ('Its Not Blocked');</script>";
       

	   }
	   else
	   {
	   echo "<script language=javascript>alert ('The Card Has being Blocked');</script>";
       echo "<meta http-equiv='refresh' content='0;url=index.html'>";

	   }
	  
	  }
	  ?>
