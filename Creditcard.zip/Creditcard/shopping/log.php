<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<?php

include("connection.php");

?>
<?php
$user=$_POST['usn'];
$passw=$_POST['psw'];
$name = mysql_real_escape_string($user);
{
error_reporting(0);
ob_start(); 
session_start();
session_destroy();
 $select="select * from registor where usname='$name' and pass='$passw'";
	  	$query=mysql_query($select);
	  	$row=mysql_num_rows($query);
		if($row>0)
		{
				session_start(); 
				$_SESSION['UserId']=$name;
				echo "<meta http-equiv='refresh' content='0;url=b_index.php'>";
				
				}
				else if(($name=='admin' and $passw=='admin')) 
				{
				echo "<meta http-equiv='refresh' content='0;url=Admin/Adminhome.html'>";
				}
				else
				{
				echo "<script type='text/javascript'> alert('Invalid Login');</script>";

	echo "<meta http-equiv='refresh' content='0;url=index.html'>";
	
						
				}
				}
?>
</body>
</html>
