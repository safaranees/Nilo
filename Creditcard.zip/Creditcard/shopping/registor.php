<?php

include("connection.php");

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Book Store</title>
<meta name="keywords" content="Book Store Template, Free CSS Template, CSS Website Layout, CSS, HTML, TemplateMo.com" />
<meta name="description" content="Book Store Template, Free CSS Template, Download CSS Website from TemplateMo.com" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />

</head>
<body>
<!--  Free CSS Templates from www.templatemo.com -->
<div id="templatemo_container">
  <div id="templatemo_menu">
    <ul>
      <li><a href="index.html">Home</a></li>
      <li><a href="registor.php" class="current">Registration</a></li>
      <li><a href="books.php">Books</a></li>
    </ul>
  </div>
  <!-- end of menu -->
  <div id="templatemo_header">
    <div id="templatemo_special_offers">
      <p> <span>25%</span> discounts for
        purchase over $ 40 </p>
      <a href="#" style="margin-left: 50px;">Read more...</a> </div>
    <div id="templatemo_new_books">
      <ul>
        <li>Suspen disse</li>
        <li>Maece nas metus</li>
        <li>In sed risus ac feli</li>
      </ul>
      <a href="#" style="margin-left: 50px;">Read more...</a> </div>
  </div>
  <!-- end of header -->
  <div id="templatemo_content">
    <div id="templatemo_content_left">
      <div class="templatemo_content_left_section">
        <h1>Categories</h1>
        <ul>
          <li><a href="index.html">Donec accumsan urna</a></li>
          <li><a href="index.html">Proin vulputate justo</a></li>
          <li><a href="#">In sed risus ac feli</a></li>
          <li><a href="#">Aliquam tristique dolor</a></li>
          <li><a href="#">Maece nas metus</a></li>
          <li><a href="#">Sed pellentesque placerat</a></li>
          <li><a href="#">Suspen disse</a></li>
          <li><a href="#">Maece nas metus</a></li>
          <li><a href="#">In sed risus ac feli</a></li>
        </ul>
      </div>
      <div class="templatemo_content_left_section">
        <h1>Bestsellers</h1>
        <ul>
          <li><a href="#">Vestibulum ullamcorper</a></li>
          <li><a href="#">Maece nas metus</a></li>
          <li><a href="#">In sed risus ac feli</a></li>
          <li><a href="#">Praesent mattis varius</a></li>
          <li><a href="#">Maece nas metus</a></li>
          <li><a href="#">In sed risus ac feli</a></li>
          <li><a href="http://www.flashmo.com" target="_parent">Flash Templates</a></li>
          <li><a href="http://www.templatemo.com" target="_parent">CSS Templates</a></li>
          <li><a href="http://www.webdesignmo.com" target="_parent">Web Design</a></li>
          <li><a href="http://www.photovaco.com" target="_parent">Free Photos</a></li>
        </ul>
      </div>
     <div class="templatemo_content_left_section">                
                <img width="172" height="41" vspace="8" border="0" src="images/index_70.gif"/></a>			</div>
        </div>
    <!-- end of content left -->
  
    <div id="templatemo_content_right">
      <h1>REGISTRATION FORM</h1>
      <form id="form1" name="form1" method="post" action="registor.php" enctype="multipart/form-data" onsubmit="return valid()">
        <table>
          <tr>
            <td colspan="2" align="center"><b><u>PERSONAL DETAILS</u></b></td>
          </tr>
          <tr>
            <td width="214" height="37" align="center"><b>Name:</b></td>
            <td width="230"><input type="text" name="name" id="name"/></td>
          </tr>
          <tr>
            <td width="214" height="32" align="center"><b>Date Of Birth:</b></td>
            <td width="230"><input type="text" name="dob" />
              <b>dd/mm/yy </b></td>
          </tr>
          <tr>
            <td width="214" height="36" align="center"><b>Gender:</b></td>
            <td width="230"><input type="radio" name="gen" value="Male" checked="checked"/>
              <b>&nbsp;MALE</b>
              <input type="radio" name="gen" value="Female"/>
              <b>&nbsp; FEMALE</b></td>
          </tr>
          <tr>
            <td width="214" height="46" align="center"><b>Address:</b></td>
            <td width="230"><textarea name="addrs"></textarea></td>
          </tr>
          <tr>
            <td width="214" height="33" align="center"><b>Mail:</b></td>
            <td width="230"><input type="text" name="email" id="mail"/></td>
          </tr>
          <tr>
            <td width="214" height="44" align="center"><b>Phone No:</b></td>
            <td width="230"><input type="text" name="phone_no" id="cno"></td>
          </tr>
          <tr>
            <td colspan="2" align="center"><b><u>LOGIN DETAILS</u></b></td>
          </tr>
          <tr>
            <td width="214" height="37" align="center"><b>UserName:</b></td>
            <td width="230"><input type="text" name="usname" /></td>
          </tr>
          <tr>
            <td width="214" height="37" align="center"><b>Password:</b></td>
            <td width="230"><input type="password" name="password" id="p"></td>
          </tr>
          <tr>
            <td width="214" height="37" align="center"><b>Confirm Password:</b></td>
            <td width="230"><input type="password" name="cpasword" id="cp"/></td>
          </tr>
          <tr>
            <td align="right"><strong>
              <input type="submit" value="SUBMIT" name="save" />
              </strong></td>
            <td align="center"><strong>
              <input type="reset" value="CLEAR" name="Clear" />
              </strong></td>
          </tr>
        </table>
      </form>
      <h2>&nbsp;</h2>
      <a href="index.html"><img src="images/templatemo_ads.jpg" alt="css template ad" /></a> </div>
    <!-- end of content right -->
    <div class="cleaner_with_height">&nbsp;</div>
  </div>
  <!-- end of content -->
<div id="templatemo_footer">
    <a href="subpage.html" style="color:#000000">Home</a> | <a href="subpage.html" style="color:#000000">Search</a> | <a href="subpage.html" style="color:#000000">Books</a> | <a href="#" style="color:#000000">New Releases</a> | <a href="#" style="color:#000000">FAQs</a> | <a href="#" style="color:#000000">Contact Us</a><br />
        Copyright © 2021</div> 
    
  <!-- end of footer -->
  <!--  Free CSS Template www.templatemo.com -->
</div>
<!-- end of container -->
</body>
</html>
<script type="text/javascript">
function echeck(str) {

		var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
		if (str.indexOf(at)==-1){
		  
		   return false
		}

		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   
		   return false
		}

		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    
		    return false
		}

		 if (str.indexOf(at,(lat+1))!=-1){
		   
		    return false
		 }

		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		   
		    return false
		 }

		 if (str.indexOf(dot,(lat+2))==-1){
		    
		    return false
		 }
		
		 if (str.indexOf(" ")!=-1){
		   
		    return false
		 }

 		 return true					
	}
	

document.getElementById('typ').focus();

    

function valid() {
	
	var frm = document.form1;
	
	

if(frm.name.value =="") { alert("Please Enter The Name."); frm.name.focus(); return false }
if(frm.dob.value =="") { alert("Please Enter The Date Of Birth."); frm.dob.focus(); return false }
if(frm.addrs.value =="") { alert("Please Enter The Address."); frm.addrs.focus(); return false }

if(frm.email.value =="") { alert("Please Enter The Email."); frm.email.focus(); return false }
if (echeck(frm.email.value)==false){alert("Email Id Is Invalid ");frm.email.focus();frm.email.value= ""; return false;}

if(frm.phone_no.value =="") { alert("Please Enter The Mobile No."); frm.phone_no.focus(); return false }
if(isNaN(frm.phone_no.value)) { alert("Mobile Number Is Invalid."); frm.phone_no.focus(); return false }
if(frm.phone_no.value.length != 10) { alert("Please Enter The 10 Digits Mobile Number ! ");frm.phone_no.focus(); return false;}


if(frm.usname.value =="") { alert("Please Enter The Username."); frm.usname.focus(); return false }
if(frm.password.value =="") { alert("Please Enter The Password."); frm.password.focus(); return false }
if(frm.cpasword.value != frm.password.value) { alert("Please Enter The Password Again");frm.cpasword.focus(); return false;}

return true;
}

</script>
  <?php




if(isset($_POST['save']) && $_POST['save']!="")

//---------------------------- First IF Starting--------------------------------
{


$name=$_POST['name'];
$dob=$_POST['dob'];
$gen=$_POST['gen'];
$address=$_POST['addrs'];
$emailid=$_POST['email'];
$contactno=$_POST['phone_no'];  
$userid=$_POST['usname'];
$password=$_POST['password'];

//---------------------------Second IF Starting----------------------------------

if($name=="" ||$dob=="" ||$gen=="" ||$address==""||$emailid==""||$contactno==""||$userid==""||$password=="")
{

echo "<script language=javascript>ProcB()</script>";

}
//---------------------------Second IF Ending----------------------------------
else
//---------------------------First ELSE Starting----------------------------------
{


$query="insert into registor (name,dob,gen,address,mail,mobno,usname,pass)values('$name','$dob','$gen','$address','$emailid','$contactno','$userid','$password')";
//echo $query;
//exit;
if (!mysql_query($query))
      {
      die ('Error: ' . mysql_error());
      }
	  
	   echo "<script language=javascript>ProcA()</script>";
	   $name="";
	   $dob=="";
	   $gen=="";
	   $address="";
	   $emailid="";
	   $contactno="";
	   $userid="";
   	   $password="";

	   

}

//---------------------------First ELSE Ending----------------------------------



}

else if(isset($_POST['Clear']) && $_POST['Clear']!="")

{
 $name="";
  $dob=="";
 $gen=="";
$address="";
$emailid="";
$contactno="";
$userid="";
$password="";

}

//------------------------------First IF Ending---------------------------------------

?>