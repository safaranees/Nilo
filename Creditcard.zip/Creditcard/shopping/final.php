
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body background="img/glass_ball.jpg">


<p>&nbsp;</p>
<p><img src="img/Flashing_lights.gif" width="1100" height="12" /><br />
  <br />
  <marquee>
    <font face="Algerian" size="+3"><br />
    Thank You Customers </font>
      </marquee>
</p>
<p><br />
  <br />

  <img src="img/Flashing_lights.gif" width="1100" height="12" />
</p>
<p align="right"><a href="logout.php">LoG OuT</a> </p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p align="center"><font face="Courier New, Courier, monospace" size="+3"><strong>Your Products will be recived Shorly<br />
 Thank You</strong></font></p>
</body>
</html>
