<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Book Store</title>
<meta name="keywords" content="Book Store Template, Free CSS Template, CSS Website Layout, CSS, HTML" />
<meta name="description" content="Book Store Template, Free CSS Template, Download CSS Website" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="../style-projects-jquery.css" />    
    <script type="text/javascript"  language="javascript">
	 history.forward();
	 </script>
    <!-- Arquivos utilizados pelo jQuery lightBox plugin -->
    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/jquery.lightbox-0.5.js"></script>
    <link rel="stylesheet" type="text/css" href="css/jquery.lightbox-0.5.css" media="screen" />
    <!-- / fim dos arquivos utilizados pelo jQuery lightBox plugin -->
    
    <!-- Ativando o jQuery lightBox plugin -->
    <script type="text/javascript">
    $(function() {
        $('#gallery a').lightBox();
    });
    </script>
   	<style type="text/css">
	/* jQuery lightBox plugin - Gallery style */
	#gallery {
		background-color: #444;
		padding: 10px;
		width: 520px;
	}
	#gallery ul { list-style: none; }
	#gallery ul li { display: inline; }
	#gallery ul img {
		border: 5px solid #3e3e3e;
		border-width: 5px 5px 20px;
	}
	#gallery ul a:hover img {
		border: 5px solid #fff;
		border-width: 5px 5px 20px;
		color: #fff;
	}
	#gallery ul a:hover { color: #fff; }
	</style>
</head>
<body>



<div id="templatemo_container">
	<div id="templatemo_menu">
    	<ul>
            <li><a href="b_index.php">Home</a></li>
            <li><a href="shopping.php">Shopping</a></li>
            <li><a href="b_gallery.php"  class="current">Books Gallery</a> </li>            
           
            <li><a href="#">Contact</a></li>
			<li><a href="index.html">Log Out</a></li> 
    	</ul>
    </div> <!-- end of menu -->
    
    <div id="templatemo_header">
    	<div id="templatemo_special_offers">
        	<p>
                <span>25%</span> discounts for
        purchase over $80
        	</p>
			<a href="" style="margin-left: 50px;">Read more...</a>
        </div>
        
        
        <div id="templatemo_new_books">
        	<ul>
                <li>Suspen disse</li>
                <li>Maece nas metus</li>
                <li>In sed risus ac feli</li>
            </ul>
            <a href="" style="margin-left: 50px;">Read more...</a>
        </div>
    </div> <!-- end of header -->
    
    <div id="templatemo_content">
    	
        <div id="templatemo_content_left">
        	<div class="templatemo_content_left_section">
            	<h1>Categories</h1>
                <ul>
                    <li><a href="">Donec accumsan urna</a></li>
                    <li><a href="">Proin vulputate justo</a></li>
                    <li><a href="#">In sed risus ac feli</a></li>
                    <li><a href="#">Aliquam tristique dolor</a></li>
                    <li><a href="#">Maece nas metus</a></li>
                    <li><a href="#">Sed pellentesque placerat</a></li>
                    <li><a href="#">Suspen disse</a></li>
                    <li><a href="#">Maece nas metus</a></li>
                    <li><a href="#">In sed risus ac feli</a></li>
            	</ul>
            </div>
			<div class="templatemo_content_left_section">
            	<h1>Bestsellers</h1>
                <ul>
                    <li><a href="#">Vestibulum ullamcorper</a></li>
                    <li><a href="#">Maece nas metus</a></li>
                    <li><a href="#">In sed risus ac feli</a></li>
                    <li><a href="#">Praesent mattis varius</a></li>
                    <li><a href="#">Maece nas metus</a></li>
                    <li><a href="#">In sed risus ac feli</a></li>
                   
            	</ul>
            </div>
            
           <div class="templatemo_content_left_section">                
                <img width="172" height="41" vspace="8" border="0" src="images/index_70.gif"/></a>
				</div></div> <!-- end of content left -->
        
        <div id="templatemo_content_right" align="center">
          
		  <h1>BOOKS GALLERY</h1>
          <p><div id="gallery">
    <ul>
        <li>
            <a href="photos/1.jpeg">
                <img src="photos/thumb_1.jpeg" width="72" height="72" alt="" />
            </a>
        </li>
        <li>
            <a href="photos/2.jpeg" >
                <img src="photos/thumb_2.jpeg" width="72" height="72" alt="" />
            </a>
        </li>
        <li>
            <a href="photos/3.jpeg" >
                <img src="photos/thumb_3.jpeg" width="72" height="72" alt="" />
            </a>
            </a>
        </li>
        <li>
            <a href="photos/4.jpeg" >
                <img src="photos/thumb_4.jpeg" width="72" height="72" alt="" />
            </a>
            </a>
        </li>
        <li>
            <a href="photos/5.jpeg" >
                <img src="photos/thumb_5.jpeg" width="72" height="72" alt="" />
            </a>
        </li>
		<li>
            <a href="photos/6.jpeg" >
                <img src="photos/thumb_6.jpeg" width="72" height="72" alt="" />
            </a>
        </li>
		<li>
            <a href="photos/7.jpeg" >
                <img src="photos/thumb_7.jpeg" width="72" height="72" alt="" />
            </a>
        </li>
		<li>
            <a href="photos/8.jpeg" >
                <img src="photos/thumb_8.jpeg" width="72" height="72" alt="" />
            </a>
        </li>
		<li>
            <a href="photos/9.jpeg" >
                <img src="photos/thumb_9.jpeg" width="72" height="72" alt="" />
            </a>
        </li>
		<li>
            <a href="photos/10.jpeg" >
                <img src="photos/thumb_10.jpeg" width="72" height="72" alt="" />
            </a>
        </li>
		<li>
            <a href="photos/11.jpeg" >
                <img src="photos/thumb_11.jpeg" width="72" height="72" alt="" />
            </a>
        </li>
		<li>
            <a href="photos/12.jpeg" >
                <img src="photos/thumb_12.jpeg" width="72" height="72" alt="" />
            </a>
        </li>
		<li>
            <a href="photos/13.jpeg" >
                <img src="photos/thumb_13.jpeg" width="72" height="72" alt="" />
            </a>
        </li>
		<li>
            <a href="photos/14.jpeg" >
                <img src="photos/thumb_14.jpeg" width="72" height="72" alt="" />
            </a>
        </li>
		<li>
            <a href="photos/15.jpeg" >
                <img src="photos/thumb_15.jpeg" width="72" height="72" alt="" />
            </a>
        </li>
		<li>
            <a href="photos/16.jpeg" >
                <img src="photos/thumb_16.jpeg" width="72" height="72" alt="" />
            </a>
        </li>
		<li>
            <a href="photos/17.jpeg" >
                <img src="photos/thumb_17.jpeg" width="72" height="72" alt="" />
            </a>
        </li>
		<li>
            <a href="photos/18.jpeg" >
                <img src="photos/thumb_18.jpeg" width="72" height="72" alt="" />
            </a>
        </li>
		<li>
            <a href="photos/19.jpeg" >
                <img src="photos/thumb_19.jpeg" width="72" height="72" alt="" />
            </a>
        </li>
		<li>
            <a href="photos/20.jpeg" >
                <img src="photos/thumb_20.jpeg" width="72" height="72" alt="" />
            </a>
        </li>
    </ul>
</div></p>
      
          
          <p>&nbsp;</p>
            
            
            <div class="cleaner_with_height">&nbsp;</div>
            
            <a href="subpage.html"><img src="images/templatemo_ads.jpg" alt="ads" /></a>
      </div> <!-- end of content right -->
    
    	<div class="cleaner_with_height">&nbsp;</div>
    </div> <!-- end of content -->
    
   <div id="templatemo_footer">
    <a href="subpage.html" style="color:#000000">Home</a> | <a href="subpage.html" style="color:#000000">Search</a> | <a href="subpage.html" style="color:#000000">Books</a> | <a href="#" style="color:#000000">New Releases</a> | <a href="#" style="color:#000000">FAQs</a> | <a href="#" style="color:#000000">Contact Us</a><br />
        Copyright © 2021</div> 
    <!-- end of footer -->
<!--  Free CSS Template www.templatemo.com -->
</div> <!-- end of container -->
</body>
</html>