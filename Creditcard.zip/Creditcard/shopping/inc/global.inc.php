<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$name = 'creditcard';
$db = &new MySQL($host,$user,$pass,$name);
?>