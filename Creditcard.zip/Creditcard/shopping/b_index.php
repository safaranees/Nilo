<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Book Store</title>
<meta name="keywords" content="Book Store Template, Free CSS Template, CSS Website Layout, CSS, HTML" />
<meta name="description" content="Book Store Template, Free CSS Template, Download CSS Website" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript"  language="javascript">
	 history.forward();
	 </script>
</head>
<body>



<div id="templatemo_container">
	<div id="templatemo_menu">
    	<ul>
            <li><a href="b_index.php" class="current">Home</a></li>
            <li><a href="shopping.php">Shopping</a></li>
            <li><a href="b_gallery.php">Books Gallery</a></li>            
           
            <li><a href="contact.html">Contact</a></li>
			<li><a href="index.html">Log Out</a></li> 
    	</ul>
    </div> <!-- end of menu -->
    
    <div id="templatemo_header">
    	<div id="templatemo_special_offers">
        	<p>
                <span>25%</span> discounts for
        purchase over $80
        	</p>
			<a href="" style="margin-left: 50px;">Read more...</a>
        </div>
        
        
        <div id="templatemo_new_books">
        	<ul>
                <li>Suspen disse</li>
                <li>Maece nas metus</li>
                <li>In sed risus ac feli</li>
            </ul>
            <a href="" style="margin-left: 50px;">Read more...</a>
        </div>
    </div> <!-- end of header -->
    
    <div id="templatemo_content">
    	
        <div id="templatemo_content_left">
        	<div class="templatemo_content_left_section">
            	<h1>Categories</h1>
                <ul>
                    <li><a href="">Donec accumsan urna</a></li>
                    <li><a href="">Proin vulputate justo</a></li>
                    <li><a href="#">In sed risus ac feli</a></li>
                    <li><a href="#">Aliquam tristique dolor</a></li>
                    <li><a href="#">Maece nas metus</a></li>
                    <li><a href="#">Sed pellentesque placerat</a></li>
                    <li><a href="#">Suspen disse</a></li>
                    <li><a href="#">Maece nas metus</a></li>
                    <li><a href="#">In sed risus ac feli</a></li>
            	</ul>
            </div>
			<div class="templatemo_content_left_section">
            	<h1>Bestsellers</h1>
                <ul>
                    <li><a href="#">Vestibulum ullamcorper</a></li>
                    <li><a href="#">Maece nas metus</a></li>
                    <li><a href="#">In sed risus ac feli</a></li>
                    <li><a href="#">Praesent mattis varius</a></li>
                    <li><a href="#">Maece nas metus</a></li>
                    <li><a href="#">In sed risus ac feli</a></li>
                    <li></li>
                </ul>
            </div>
            
            <div class="templatemo_content_left_section">                
                <img width="172" height="41" vspace="8" border="0" src="images/index_70.gif"/></a>
				</div></div>  <!-- end of content left -->
        
        <div id="templatemo_content_right">
          <p style="padding-left:20px;padding-right:20px"><br />
<strong>Credit card </strong>transactions continue to grow in number,   taking an ever-larger  share of the US payment system and leading to a   higher rate of stolen account  numbers and subsequent losses by banks.   Improved fraud detection thus has  become essential to maintain the   viability of the US payment system. Banks have  used early fraud warning   systems for some years. Large-scale data-mining  techniques can improve   on the state of the art in commercial practice. Scalable  techniques to   analyze massive amounts of transaction data that efficiently compute    fraud detectors in a timely manner is an important problem, especially   for  e-commerce. Besides scalability and efficiency, the fraud-detection   task  exhibits technical problems that include skewed distributions of   training data  and nonuniform cost per error, both of which have not   been widely studied in  the knowledge-discovery and datamining   community. In this article, we survey  and evaluate a number of   techniques that address these three main issues  concurrently. Our   proposed methods of combining multiple learned fraud detectors  under a   “cost model” are general and demonstrably useful; our empirical results    demonstrate that we can significantly reduce loss due to fraud through    distributed data mining of fraud models</p>
          <p <p style="padding-left:20px;padding-right:20px"><br /><strong>In today’s</strong> increasingly  electronic society and with   the rapid advances of electronic commerce on the  Internet, the use of   credit cards for purchases has become convenient and  necessary. Credit   card transactions have become the de facto standard for  Internet and   Webbased e-commerce. The US government estimates that credit cards    accounted for approximately US $13 billion in Internet sales during   1998. This  figure is expected to grow rapidly each year. However, the   growing number of credit  card transactions provides more opportunity   for thieves to steal credit card  numbers and subsequently commit fraud.   When banks lose  money because of credit card fraud, cardholders pay   for all of that loss  through higher interest rates, higher fees, and   reduced benefits.Hence, it is in  both the banks’</p>
          <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            
            <div class="cleaner_with_height">&nbsp;</div>
            
            <a href="subpage.html"><img src="images/templatemo_ads.jpg" alt="ads" /></a>
      </div> <!-- end of content right -->
    
    	<div class="cleaner_with_height">&nbsp;</div>
    </div> <!-- end of content -->
    
    <div id="templatemo_footer">
    <a href="subpage.html" style="color:#000000">Home</a> | <a href="subpage.html" style="color:#000000">Search</a> | <a href="subpage.html" style="color:#000000">Books</a> | <a href="#" style="color:#000000">New Releases</a> | <a href="#" style="color:#000000">FAQs</a> | <a href="#" style="color:#000000">Contact Us</a><br />
        Copyright © 2021</div> 
    <!-- end of footer -->
<!--  Free CSS Template www.templatemo.com -->
</div> <!-- end of container -->
</body>
</html>