<?php
include "connection.php";
session_start();
error_reporting(0);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Book Store</title>
<meta name="keywords" content="Book Store Template, Free CSS Template, CSS Website Layout, CSS, HTML" />
<meta name="description" content="Book Store Template, Free CSS Template, Download CSS Website" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript"  language="javascript">
	 history.forward();
	 </script>
<script type="text/javascript">

function Mod10(ccNumb) {  // v2.0
var valid = "0123456789"  // Valid digits in a credit card number
var len = ccNumb.length;  // The length of the submitted cc number
var iCCN = parseInt(ccNumb);  // integer of ccNumb
var sCCN = ccNumb.toString();  // string of ccNumb
sCCN = sCCN.replace (/^\s+|\s+$/g,'');  // strip spaces
var iTotal = 0;  // integer total set at zero
var bNum = true;  // by default assume it is a number
var bResult = false;  // by default assume it is NOT a valid cc
var temp;  // temp variable for parsing string
var calc;  // used for calculation of each digit

// Determine if the ccNumb is in fact all numbers
for (var j=0; j<len; j++) {
  temp = "" + sCCN.substring(j, j+1);
  if (valid.indexOf(temp) == "-1"){bNum = false;}
}

// if it is NOT a number, you can either alert to the fact, or just pass a failure
if(!bNum){
  /*alert("Not a Number");*/bResult = false;
}

// Determine if it is the proper length 
if((len == 0)&&(bResult)){  // nothing, field is blank AND passed above # check
  bResult = false;
} else{  // ccNumb is a number and the proper length - let's see if it is a valid card number
  if(len >= 15){  // 15 or 16 for Amex or V/MC
    for(var i=len;i>0;i--){  // LOOP throught the digits of the card
      calc = parseInt(iCCN) % 10;  // right most digit
      calc = parseInt(calc);  // assure it is an integer
      iTotal += calc;  // running total of the card number as we loop - Do Nothing to first digit
      i--;  // decrement the count - move to the next digit in the card
      iCCN = iCCN / 10;                               // subtracts right most digit from ccNumb
      calc = parseInt(iCCN) % 10 ;    // NEXT right most digit
      calc = calc *2;                                 // multiply the digit by two
      // Instead of some screwy method of converting 16 to a string and then parsing 1 and 6 and then adding them to make 7,
      // I use a simple switch statement to change the value of calc2 to 7 if 16 is the multiple.
      switch(calc){
        case 10: calc = 1; break;       //5*2=10 & 1+0 = 1
        case 12: calc = 3; break;       //6*2=12 & 1+2 = 3
        case 14: calc = 5; break;       //7*2=14 & 1+4 = 5
        case 16: calc = 7; break;       //8*2=16 & 1+6 = 7
        case 18: calc = 9; break;       //9*2=18 & 1+8 = 9
        default: calc = calc;           //4*2= 8 &   8 = 8  -same for all lower numbers
      }                                               
    iCCN = iCCN / 10;  // subtracts right most digit from ccNum
    iTotal += calc;  // running total of the card number as we loop
  }  // END OF LOOP
  if ((iTotal%10)==0){  // check to see if the sum Mod 10 is zero
    bResult = true;  // This IS (or could be) a valid credit card number.
  } else {
    bResult = false;  // This could NOT be a valid credit card number
    }
  }
}
// change alert to on-page display or other indication as needed.
if(bResult) {
  alert("This IS a valid Credit Card Number!");
}
if(!bResult){
  alert("This is NOT a valid Credit Card Number!");
  document.getElementById("CNUM").value="";
}
  return bResult; // Return the results
}
</script>
<script type="text/javascript"  language="javascript">
function ProcB () 
	 {
		alert ("Enter All The Values");
	 }
	  function ProcA () 
	 {
		alert ("Payment Done Successfully ");
	 }
	 function ProcC () 
	 {
		alert ("Informations are wrong ");
	 }
	 </script>
</head>
<body>



<div id="templatemo_container">
	<div id="templatemo_menu">
    	<ul>
            <li><a href="index.html">Home</a></li>
             <li><a href="shopping.php" class="current">Shopping</a></li>
            <li><a href="b_gallery.php">Books Gallery</a></li>            
           
            <li><a href="#">Contact</a></li>
			<li><a href="index.html">Log Out</a></li> 
    	</ul>
    </div> <!-- end of menu -->
    
    <div id="templatemo_header">
    	<div id="templatemo_special_offers">
        	<p>
                <span>25%</span> discounts for
        purchase over $80
        	</p>
			<a href="" style="margin-left: 50px;">Read more...</a>
        </div>
        
        
        <div id="templatemo_new_books">
        	<ul>
                <li>Suspen disse</li>
                <li>Maece nas metus</li>
                <li>In sed risus ac feli</li>
            </ul>
            <a href="" style="margin-left: 50px;">Read more...</a>
        </div>
    </div> <!-- end of header -->
    
    <div id="templatemo_content">
    	
        <div id="templatemo_content_left">
        	<div class="templatemo_content_left_section">
            	<h1>Categories</h1>
                <ul>
                    <li><a href="">Donec accumsan urna</a></li>
                    <li><a href="">Proin vulputate justo</a></li>
                    <li><a href="#">In sed risus ac feli</a></li>
                    <li><a href="#">Aliquam tristique dolor</a></li>
                    <li><a href="#">Maece nas metus</a></li>
                    <li><a href="#">Sed pellentesque placerat</a></li>
                    <li><a href="#">Suspen disse</a></li>
                    <li><a href="#">Maece nas metus</a></li>
                    <li><a href="#">In sed risus ac feli</a></li>
            	</ul>
            </div>
			<div class="templatemo_content_left_section">
            	<h1>Bestsellers</h1>
                <ul>
                    <li><a href="#">Vestibulum ullamcorper</a></li>
                    <li><a href="#">Maece nas metus</a></li>
                    <li><a href="#">In sed risus ac feli</a></li>
                    <li><a href="#">Praesent mattis varius</a></li>
                    <li><a href="#">Maece nas metus</a></li>
                    <li><a href="#">In sed risus ac feli</a></li>
                    
            	</ul>
            </div>
            
    <div class="templatemo_content_left_section">                
                <img width="172" height="41" vspace="8" border="0" src="images/index_70.gif"/></a>
				</div></div>  <!-- end of content left -->
        <?php
if(isset($_POST['save']) && $_POST['save']!="")
{
$hnam=$_POST['hname'];
$cnum=$_POST['CreditCard'];
$pnum=$_POST['pnum'];
$q1=$_POST['q1'];
$ans=$_POST['ans'];
$pay=$_POST['typ'];
$totl=$_POST['tot'];
//echo $hnam; echo $cnum; echo $pnum; echo $q1; echo $ans; echo $pay;
 if($hnam=="" ||$cnum=="" ||$pnum=="" ||$q1=="" ||$ans=="")
{

echo "<script language=javascript>ProcB()</script>";

} 
else
{
$select="select * from carddetail where holder='$hnam' and cno='$cnum' and typ='$pay' and cardpin='$pnum' and q1='$q1' and answer='$ans'";
$query=mysql_query($select);
	  	$row=mysql_num_rows($query);
		if($row>0)
	{
	session_start();
	$_SESSION['hnam']= $hnam;
	$_SESSION['cnum']= $cnum; 
	$_SESSION['pnum']= $pnum; 
	$_SESSION['q1']= $q1; 
	$_SESSION['ans']= $ans; 
	$_SESSION['pay']= $pay;
	 $_SESSION['totl']= $totl;
	 //include "conn.php";
//	echo $hnam; echo $cnum; echo $pnum; echo $q1; echo $ans; echo $pay; echo $totl;

	$query="insert into pur(`hnam`, `pay`, `total`)values('".$hnam."','".$cnum."','".$_SESSION['total_payment']."')";
	//echo $query;
//	exit;
	echo "<script language=javascript>ProcA()</script>";
	echo "<meta http-equiv='refresh' content='0;url=final.php'>";
		 
	if(!mysql_query($query))
	{
	echo "Error";
	}echo "<meta http-equiv='refresh' content='0;url=final.php'>";
	 }
	else
	{
 	 echo "<script language=javascript>ProcC()</script>";
	}

}

	
	 


}
?>
<?php

$tot=$_POST['total'];
?>
        <div id="templatemo_content_right">
		

<h1>Welcome to Payment Section</h1>

<form action="" method="post" name="Form1">
<table width="596" height="398" border="4" align="center" bordercolor="#000000">
<tr><td width="254" height="54"><strong>Total</strong></td>
<td width="322" align="center"><input type="hidden" value="<?php echo $tot; ?>" name="tot" /><b>Rs.<?php echo $_SESSION['total_payment']; ?></b></td>
</tr>
<tr><td width="254"><strong>Payment By</strong></td>
<td><select name="typ">
					<option>Select the Card type</option>
					 <option value="MasterCard">MasterCard</option>
      <option value="American Express">American Express</option>
      <option value="Carte Blanche">Carte Blanche</option>
      <option value="Diners Club">Diners Club</option>

      <option value="Discover">Discover</option>
      <option value="Enroute">enRoute</option>
      <option value="JCB">JCB</option>
      <option value="Maestro">Maestro</option>
      <option value="MasterCard">MasterCard</option>
      <option value="Solo">Solo</option>

      <option value="Switch">Switch</option>
      <option value="Visa">Visa</option>
      <option value="Visa Electron">Visa Electron</option>
      <option value="LaserCard">Laser</option>

					</select></td></tr>

<tr><td width="254"><strong>HolderName</strong></td>
<td><input type="text" name="hname"/></td></tr>
<tr><td><strong>Card No</strong></td>
<td><input type="text" name="CreditCard" ID="CNUM" size="18" maxlength="16" style="border: 1px solid #000098; padding: 3px;" /></td></tr>
<tr><td><strong>Pin No</strong></td>
<td><input type="text" name="pnum"/></td></tr>
<tr><td><strong>Questions</strong></td>
<td><select name="q1">
					<option>Select the Question</option>
					 <option value="Personal Mobile Number">Personal Mobile Number</option>
      <option value="Name of My Pet">Name of My Pet</option>
      <option value="My Byk Num">My Byk Num</option>
      <option value="My Co_Brother Name">My Co_Brother Name</option>

      <option value="My Enemy Name">My Enemy Name</option>
      <option value="My Dish">My Dish</option>
      <option value="My Girl Name">My Girl Name</option>
      <option value="My Boy Name">My Boy Name</option>
      <option value="My Nick NAme">My Nick NAme</option>
      <option value="My Name">My Name</option>

     
					</select></td></tr>
<tr><td><strong>Answers</strong></td>
<td><input type="text" name="ans"/></td></tr>
<tr><td align="center"><a href="cart.php" style="color:#000000"><strong><<-- Back</strong></a></td>
  <td><input name="save" type="submit" class="style1" value="Proceed>>>" /></td>
</tr>
</table>
</form>

            <p>&nbsp;</p>
            <p>&nbsp;</p>
            
            <div class="cleaner_with_height">&nbsp;</div>
            
            <a href="subpage.html"><img src="images/templatemo_ads.jpg" alt="ads" /></a>
      </div> <!-- end of content right -->
    
    	<div class="cleaner_with_height">&nbsp;</div>
    </div> <!-- end of content -->
    
    <div id="templatemo_footer">
    <a href="subpage.html" style="color:#000000">Home</a> | <a href="subpage.html" style="color:#000000">Search</a> | <a href="subpage.html" style="color:#000000">Books</a> | <a href="#" style="color:#000000">New Releases</a> | <a href="#" style="color:#000000">FAQs</a> | <a href="#" style="color:#000000">Contact Us</a><br />
        Copyright © 2021</div> 
    <!-- end of footer -->
<!--  Free CSS Template www.templatemo.com -->
</div> <!-- end of container -->
</body>
</html>