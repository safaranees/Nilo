<?php
include "connection.php";

session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Bank</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>

   <!-- Begin Wrapper -->
   <div id="wrapper">
   
         <!-- Begin Header -->
         <div id="header">
		 
                <div class="logo">
		<h1 id="lineone"><strong><font color="#000000" face="Algerian" size="+2">DISTRIBUTED DATA MINING IN CREDIT<br />
CARD FRAUD DETECTION</font></strong></h1> 
		<h2 id="linetwo"></h2>
           </div>
	 
			   
		 </div>
		 <!-- End Header -->
		 
		 <!-- Begin Navigation -->
         <div id="navigation">
		 
	<div class="menu">

	        
	        <ul>
			<li><a href="index.html"> Home </a>
			</li>
			<li><a href="#" title="#">Card Registration </a></li>
			<li><a href="abtous.html">About Us</a></li>
                        <li><a href="cardblock.php">Block Card</a></li>
                        <li><a href="#">Contact Us</a></li>
		</ul>
	</div>
	 
			   
		 </div>
		 <!-- End Navigation -->
		 
		 <!-- Begin Left Column -->
		 <div id="leftcolumn">
		 
			<div id="leftbox">
                        
                        <div class="col-l">
	        <ul>
			<li><a href="" title="free business templates">Home</a></li>
			<li><a href="#" title="#">Card Registration</a><a href="" title="earn money online"></a></li>
			<li><a href="#" title="#">About Us</a></li>
                        <li><a href="#" title="#">Block Card</a></li>
                        <li><a href="#" title="#">Contact Us</a></li>
		</ul>
              </div>
           </div>
                        <div id="leftboxbottom"></div>
            
                             <br/>

			<div id="leftbox-2">
                        
                        <div class="col-l">
	                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec rutrum neque eu nisl. Morbi eget felis. Vestibulum feugiat lectus ut magna. Ut interdum <a href="#">ipsum nec metus</a>. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Ut eget augue .</p>
                        </div>
                        </div>
                        <div id="leftboxbottom-2"></div>
		 
		 </div>
		 <!-- End Left Column -->
		 
		 <!-- Begin Right Column -->
		 <div id="rightcolumn">
                 <blockquote><p><span class="title">Credit Card Fraud Detection</span></p>
                 </blockquote>
		       
           <div id="doublebox"></div>



                <h4>Please Note your Card Pin Number &nbsp;&nbsp;&nbsp;&nbsp;<font face="Algerian" color="#000000" size="+3">
	    <?php  
		echo $_SESSION['random_chars'];
		?></font></h4>
                <h4>&nbsp;</h4>
                <h4>&nbsp;</h4>
                <h4>Lorem Ipsum</h4>
                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec rutrum neque eu nisl. Morbi eget felis. Vestibulum feugiat lectus ut magna. Ut interdum ipsum nec metus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia. </p>

                 <div class="clear"></div>

		<div id="triplebox">
			<div class="col">
                <img src="images/globe-s.gif" class="floatTL" alt="business" />
				<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>
			</div>
			
			<div class="col">

                <img src="images/globe-s.gif" class="floatTL" alt="business" />
				<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>
			</div>

			<div class="col">

                <img src="images/globe-s.gif" class="floatTL" alt="business" />
				<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. </p>
			</div>
		
           </div>
                 <div class="clear"></div>
		<div id="tripleboxbottom"></div>
		 
		 </div>

		 <!-- End Right Column -->
		 
		 <!-- Begin Footer -->
 <div id="footer">
	<p id="links"><a href="">Valid XHTML</a> | <a href="">Valid CSS</a></p>
	<p id="legal">Copyright &copy; 2007  by Free CSS Templates  Designed by <a href="">FEEE CSS TEMPLATES</a>.</p>
</div>
		 <!-- End Footer -->
		 
   </div>
   <!-- End Wrapper -->
   
</body>
</html>
