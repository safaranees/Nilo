<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script type="text/javascript"  language="javascript">


	  function ProcB () 
	 {
		alert ("Enter All The Values");
	 }
	  function ProcA () 
	 {
		alert ("Registered Successfully <?PHP echo $Cname; ?>");
	 }
	  function ProcC () 
	 {
		alert ("Password Not Matched ");
	 }
	  function alertbox (obj) 
	 {
		alert (obj);
	 }
	 function isEmpty(inputStr) {
if ( inputStr == "" ) {
return true;
}
else {
return false;
}
}
function passLength()
{
if(document.getElementById("p").value<16)
{
alert("Enter the Correct Card No");
}
}


	 </script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<form action="" method="post">
			  <table width="451" height="641" border="3" bordercolor="#000000" background="images/background5.jpg">
                      <tr>
					<td width="173" height="38" align=""><font color="#000000" size="+1"><B>Card Holder Name </B></font></td>
					<td width="266" align="center"><input type="text" name="holnam" /></td></tr>
					<td height="51" align=""><font color="#000000" size="+1"><B>Bank Name</B></font> </td>
					<td align="center"><input type="text" name="bnknam" /></td></tr>
					<td height="54" align=""><font color="#000000" size="+1"><B>Branch Name </B></font></td>
					<td align="center"><input type="text" name="bnhnam" /></td></tr>
					<td height="52" align=""><font color="#000000" size="+1"><B>Card Type</B></font> </td>
					<td align="center">
					<select name="typ">
					<option>Select the Card type</option>
					 <option value="Debit Card">Debit Card</option>
					 <option value="Credit Card">Credit Card</option>
					</select></td></tr>
					<tr><td height="54" align=""><font color="#000000" size="+1"><B>Card No </B></font></td>
					<td align="center"><input type="text" name="cno" id="p"  onchange="passLength(this)" /></td></tr>
					<tr><td height="74" align=""><font color="#000000" size="+1"><B>Amount Limit </B></font></td>
					<td align="">
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="amtlimt" value="100000 to 150000" />&nbsp;<B>1 lakh to 1.5 lakh</B> <br />
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="amtlimt" value="50000 to 99999 " />&nbsp;<B>Above 50000 to Below 100000</B> <br />
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="amtlimt" value="49999" />&nbsp;<B>Below 50000 </B></td></tr>
						<tr><td height="54" align=""><font color="#000000" size="+1"><B>Question 1 </B></font></td>
					<td align="center"><input type="text" name="q1" /></td></tr>
					<tr><td height="54" align="" ><font color="#000000" size="+1"><B>Answer 1 </B></font></td>
					<td align="center"><input type="text" name="ans1" /></td></tr>
					<tr><td height="73" colspan="2" align="center"><img src="CaptchaSecurityImages.php?width=100&height=40&characters=5" /></td>
					<tr><td height="54" align=""><font color="#000000" size="+1"><B>Security Code:</B></font></td>
					<td align="center"><input id="security_code" name="security_code" type="text" /></td></tr>
					<TR><TD height="45" colspan="2" align="CENTER"><input type="submit" value="SUBMIT" name="save" /></TD></TR>
			  </table>
			  </form>
</body>
</html>
